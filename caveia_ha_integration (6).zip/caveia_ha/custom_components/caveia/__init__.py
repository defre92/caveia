"""L'intégration CaveIA."""
from __future__ import annotations

import logging

import voluptuous as vol

from homeassistant.config_entries import ConfigEntry
from homeassistant.core import CoreState, EVENT_HOMEASSISTANT_STARTED, HomeAssistant, ServiceCall
from homeassistant.exceptions import HomeAssistantError
from homeassistant.helpers import config_validation as cv, entity_registry as er
from homeassistant.helpers.service import async_extract_entity_ids

from .const import (
    ATTR_BOTTLE_ID, ATTR_CIGAR_ID, ATTR_HUMIDITY, ATTR_POSITION_INDEX, ATTR_TEMPERATURE,
    DOMAIN, SERVICE_CONSUME_BOTTLE, SERVICE_CONSUME_CIGAR, SERVICE_SET_CONDITIONS, UID_SEP,
)
from .coordinator import CaveiaCoordinator
from .frontend import JSModuleRegistration

_LOGGER = logging.getLogger(__name__)

PLATFORMS = ["sensor", "todo"]

SET_CONDITIONS_SCHEMA = cv.make_entity_service_schema(
    {
        vol.Optional(ATTR_TEMPERATURE): vol.Coerce(float),
        vol.Optional(ATTR_HUMIDITY): vol.Coerce(float),
    }
)

CONSUME_BOTTLE_SCHEMA = vol.Schema({
    vol.Required(ATTR_BOTTLE_ID): str,
    vol.Optional(ATTR_POSITION_INDEX): vol.Coerce(int),
})

CONSUME_CIGAR_SCHEMA = vol.Schema({
    vol.Required(ATTR_CIGAR_ID): str,
})


async def async_setup(hass: HomeAssistant, config: dict) -> bool:
    """Enregistre la carte Lovelace embarquée (une seule fois, indépendamment
    du nombre d'entrées de configuration)."""

    async def _register_frontend(_event=None) -> None:
        await JSModuleRegistration(hass).async_register()

    if hass.state == CoreState.running:
        await _register_frontend()
    else:
        hass.bus.async_listen_once(EVENT_HOMEASSISTANT_STARTED, _register_frontend)

    return True


async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Initialise CaveIA à partir d'une entrée de configuration."""
    coordinator = CaveiaCoordinator(hass, entry)
    await coordinator.async_config_entry_first_refresh()

    hass.data.setdefault(DOMAIN, {})
    hass.data[DOMAIN][entry.entry_id] = {"coordinator": coordinator}

    await hass.config_entries.async_forward_entry_setups(entry, PLATFORMS)

    entry.async_on_unload(entry.add_update_listener(_async_update_listener))

    if not hass.services.has_service(DOMAIN, SERVICE_SET_CONDITIONS):
        hass.services.async_register(
            DOMAIN,
            SERVICE_SET_CONDITIONS,
            _make_set_conditions_handler(hass),
            schema=SET_CONDITIONS_SCHEMA,
        )

    if not hass.services.has_service(DOMAIN, SERVICE_CONSUME_BOTTLE):
        hass.services.async_register(
            DOMAIN,
            SERVICE_CONSUME_BOTTLE,
            _make_consume_bottle_handler(hass),
            schema=CONSUME_BOTTLE_SCHEMA,
        )

    if not hass.services.has_service(DOMAIN, SERVICE_CONSUME_CIGAR):
        hass.services.async_register(
            DOMAIN,
            SERVICE_CONSUME_CIGAR,
            _make_consume_cigar_handler(hass),
            schema=CONSUME_CIGAR_SCHEMA,
        )

    return True


async def _async_update_listener(hass: HomeAssistant, entry: ConfigEntry) -> None:
    """Recharge l'intégration quand les options changent (ex. intervalle)."""
    await hass.config_entries.async_reload(entry.entry_id)


async def async_unload_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Décharge l'intégration."""
    unload_ok = await hass.config_entries.async_unload_platforms(entry, PLATFORMS)
    if unload_ok:
        hass.data[DOMAIN].pop(entry.entry_id)
        if not hass.data[DOMAIN]:
            hass.services.async_remove(DOMAIN, SERVICE_SET_CONDITIONS)
            hass.services.async_remove(DOMAIN, SERVICE_CONSUME_BOTTLE)
            hass.services.async_remove(DOMAIN, SERVICE_CONSUME_CIGAR)
    return unload_ok


def _make_set_conditions_handler(hass: HomeAssistant):
    async def _handle_set_conditions(call: ServiceCall) -> None:
        temperature = call.data.get(ATTR_TEMPERATURE)
        humidity = call.data.get(ATTR_HUMIDITY)
        if temperature is None and humidity is None:
            raise HomeAssistantError("Renseigne au moins la température ou l'humidité")

        entity_ids = await async_extract_entity_ids(call)
        if not entity_ids:
            raise HomeAssistantError("Aucune entité CaveIA ciblée")

        ent_reg = er.async_get(hass)

        for entity_id in entity_ids:
            reg_entry = ent_reg.async_get(entity_id)
            if reg_entry is None or reg_entry.platform != DOMAIN or not reg_entry.unique_id:
                _LOGGER.warning("%s n'est pas une entité CaveIA, ignorée", entity_id)
                continue

            parts = reg_entry.unique_id.split(UID_SEP)
            # unique_id attendu : "<entry_id>::cellar::<cellar_id>" ou "<entry_id>::humidor::<humidor_id>"
            if len(parts) != 3 or parts[1] not in ("cellar", "humidor"):
                _LOGGER.warning("%s n'est pas une cave ni un humidor CaveIA, ignorée", entity_id)
                continue

            config_entry_id, kind, item_id = parts
            entry_data = hass.data.get(DOMAIN, {}).get(config_entry_id)
            if entry_data is None:
                _LOGGER.warning("Config CaveIA introuvable pour %s", entity_id)
                continue

            coordinator: CaveiaCoordinator = entry_data["coordinator"]
            await coordinator.async_push_conditions(kind, item_id, temperature, humidity)

    return _handle_set_conditions


def _first_coordinator(hass: HomeAssistant) -> CaveiaCoordinator:
    """Renvoie le premier coordinator CaveIA disponible.
    NB : si tu connectes un jour plusieurs comptes CaveIA à la fois, ces
    services agiront toujours sur le premier compte configuré."""
    entries = hass.data.get(DOMAIN, {})
    if not entries:
        raise HomeAssistantError("Aucune intégration CaveIA configurée")
    return next(iter(entries.values()))["coordinator"]


def _make_consume_bottle_handler(hass: HomeAssistant):
    async def _handle_consume_bottle(call: ServiceCall) -> None:
        bottle_id = call.data[ATTR_BOTTLE_ID]
        position_index = call.data.get(ATTR_POSITION_INDEX)
        coordinator = _first_coordinator(hass)
        await coordinator.async_sortie_bottle(bottle_id, position_index=position_index)

    return _handle_consume_bottle


def _make_consume_cigar_handler(hass: HomeAssistant):
    async def _handle_consume_cigar(call: ServiceCall) -> None:
        cigar_id = call.data[ATTR_CIGAR_ID]
        coordinator = _first_coordinator(hass)
        await coordinator.async_fumer_cigar(cigar_id)

    return _handle_consume_cigar
