"""Capteurs CaveIA.

- 4 capteurs globaux : bouteilles totales, à boire, apogée, cigares disponibles.
- 1 capteur par cave et 1 capteur par humidor, créés dynamiquement à partir
  des données de l'export. Si une nouvelle cave/humidor apparaît côté CaveIA,
  son capteur est ajouté automatiquement au prochain rafraîchissement — sans
  reconfigurer l'intégration.
"""
from __future__ import annotations

from homeassistant.components.sensor import SensorEntity, SensorEntityDescription
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant, callback
from homeassistant.helpers.entity import DeviceInfo
from homeassistant.helpers.entity_platform import AddEntitiesCallback
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from .const import DOMAIN, MANUFACTURER, UID_SEP
from .coordinator import CaveiaCoordinator

GLOBAL_SENSOR_DESCRIPTIONS = [
    SensorEntityDescription(key="bottles_total", name="Bouteilles totales", icon="mdi:bottle-wine"),
    SensorEntityDescription(key="a_boire", name="À boire", icon="mdi:glass-wine"),
    SensorEntityDescription(key="apogee", name="Apogée", icon="mdi:alert"),
    SensorEntityDescription(key="cigars_available", name="Cigares disponibles", icon="mdi:cigar"),
]


def _device_info(entry: ConfigEntry) -> DeviceInfo:
    return DeviceInfo(
        identifiers={(DOMAIN, entry.entry_id)},
        name="CaveIA",
        manufacturer=MANUFACTURER,
        entry_type="service",
    )


async def async_setup_entry(
    hass: HomeAssistant, entry: ConfigEntry, async_add_entities: AddEntitiesCallback
) -> None:
    coordinator: CaveiaCoordinator = hass.data[DOMAIN][entry.entry_id]["coordinator"]
    known_ids: set[str] = set()

    entities = [CaveiaGlobalSensor(coordinator, entry, desc) for desc in GLOBAL_SENSOR_DESCRIPTIONS]
    async_add_entities(entities)

    @callback
    def _add_new_items() -> None:
        data = coordinator.data or {}
        new_entities = []

        for c in data.get("cellars", []):
            uid = f"cellar{UID_SEP}{c['id']}"
            if uid not in known_ids:
                known_ids.add(uid)
                new_entities.append(CaveiaCellarSensor(coordinator, entry, c["id"]))

        for h in data.get("humidors", []):
            uid = f"humidor{UID_SEP}{h['id']}"
            if uid not in known_ids:
                known_ids.add(uid)
                new_entities.append(CaveiaHumidorSensor(coordinator, entry, h["id"]))

        if new_entities:
            async_add_entities(new_entities)

    _add_new_items()
    entry.async_on_unload(coordinator.async_add_listener(_add_new_items))


class CaveiaGlobalSensor(CoordinatorEntity[CaveiaCoordinator], SensorEntity):
    """Capteur global (compteurs sur l'ensemble de la cave)."""

    _attr_has_entity_name = True

    def __init__(self, coordinator: CaveiaCoordinator, entry: ConfigEntry, description: SensorEntityDescription) -> None:
        super().__init__(coordinator)
        self.entity_description = description
        self._attr_unique_id = f"{entry.entry_id}{UID_SEP}{description.key}"
        self._attr_device_info = _device_info(entry)

    @property
    def native_value(self):
        data = self.coordinator.data or {}
        key = self.entity_description.key
        if key == "bottles_total":
            return data.get("bottles", {}).get("total", 0)
        if key == "a_boire":
            return data.get("bottles", {}).get("a_boire_count", 0)
        if key == "apogee":
            return data.get("bottles", {}).get("apogee_count", 0)
        if key == "cigars_available":
            return len(data.get("cigars_available", []))
        return None

    @property
    def extra_state_attributes(self):
        data = self.coordinator.data or {}
        key = self.entity_description.key
        if key == "bottles_total":
            return {
                "a_boire": data.get("bottles", {}).get("a_boire", []),
                "apogee": data.get("bottles", {}).get("apogee", []),
            }
        if key == "cigars_available":
            return {"cigars": data.get("cigars_available", [])}
        return None


class CaveiaCellarSensor(CoordinatorEntity[CaveiaCoordinator], SensorEntity):
    """Un capteur par cave : état = % de remplissage, attributs = détails."""

    _attr_has_entity_name = True
    _attr_native_unit_of_measurement = "%"
    _attr_icon = "mdi:home-variant"

    def __init__(self, coordinator: CaveiaCoordinator, entry: ConfigEntry, cellar_id: str) -> None:
        super().__init__(coordinator)
        self._cellar_id = cellar_id
        self._entry = entry
        self._attr_unique_id = f"{entry.entry_id}{UID_SEP}cellar{UID_SEP}{cellar_id}"
        self._attr_device_info = _device_info(entry)

    def _cellar(self) -> dict | None:
        for c in (self.coordinator.data or {}).get("cellars", []):
            if c["id"] == self._cellar_id:
                return c
        return None

    @property
    def name(self):
        c = self._cellar()
        return c["name"] if c else "Cave (supprimée)"

    @property
    def native_value(self):
        c = self._cellar()
        return c["pct"] if c else None

    @property
    def available(self) -> bool:
        return self._cellar() is not None

    @property
    def extra_state_attributes(self):
        c = self._cellar()
        if not c:
            return None
        return {
            "cellar_id": c["id"],
            "occupied": c.get("occupied"),
            "total": c.get("total"),
            "temperature": c.get("temperature"),
            "humidity": c.get("humidity"),
            "humidity_at": c.get("humidity_at"),
            "bottles": c.get("bottles", []),
        }


class CaveiaHumidorSensor(CoordinatorEntity[CaveiaCoordinator], SensorEntity):
    """Un capteur par humidor : état = humidité, attributs = détails."""

    _attr_has_entity_name = True
    _attr_native_unit_of_measurement = "%"
    _attr_icon = "mdi:archive"

    def __init__(self, coordinator: CaveiaCoordinator, entry: ConfigEntry, humidor_id: str) -> None:
        super().__init__(coordinator)
        self._humidor_id = humidor_id
        self._entry = entry
        self._attr_unique_id = f"{entry.entry_id}{UID_SEP}humidor{UID_SEP}{humidor_id}"
        self._attr_device_info = _device_info(entry)

    def _humidor(self) -> dict | None:
        for h in (self.coordinator.data or {}).get("humidors", []):
            if h["id"] == self._humidor_id:
                return h
        return None

    @property
    def name(self):
        h = self._humidor()
        return h["name"] if h else "Humidor (supprimé)"

    @property
    def native_value(self):
        h = self._humidor()
        return h["humidity"] if h else None

    @property
    def available(self) -> bool:
        return self._humidor() is not None

    @property
    def extra_state_attributes(self):
        h = self._humidor()
        if not h:
            return None
        return {
            "humidor_id": h["id"],
            "temperature": h.get("temperature"),
            "humidity_at": h.get("humidity_at"),
        }
