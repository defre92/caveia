"""Enregistrement de la carte Lovelace CaveIA comme ressource frontend.

Sert le fichier JS via un chemin HTTP statique et l'ajoute automatiquement
aux ressources Lovelace (mode storage) — l'utilisateur n'a rien à faire
manuellement, la carte est disponible dès que l'intégration est configurée.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from homeassistant.components.http import StaticPathConfig
from homeassistant.core import HomeAssistant
from homeassistant.helpers.event import async_call_later

from ..const import JSMODULES, URL_BASE

_LOGGER = logging.getLogger(__name__)


class JSModuleRegistration:
    """Enregistre les modules JavaScript de CaveIA dans Home Assistant."""

    def __init__(self, hass: HomeAssistant) -> None:
        self.hass = hass
        self.lovelace = self.hass.data.get("lovelace")

    async def async_register(self) -> None:
        await self._async_register_path()
        resource_mode = getattr(self.lovelace, "resource_mode", None) or getattr(self.lovelace, "mode", None)
        if self.lovelace is not None and resource_mode == "storage":
            await self._async_wait_for_lovelace_resources()

    async def _async_register_path(self) -> None:
        try:
            await self.hass.http.async_register_static_paths(
                [StaticPathConfig(URL_BASE, str(Path(__file__).parent), False)]
            )
            _LOGGER.debug("Chemin statique enregistré : %s", URL_BASE)
        except RuntimeError:
            _LOGGER.debug("Chemin statique déjà enregistré : %s", URL_BASE)

    async def _async_wait_for_lovelace_resources(self) -> None:
        async def _check_loaded(_now: Any) -> None:
            if self.lovelace.resources.loaded:
                await self._async_register_modules()
            else:
                async_call_later(self.hass, 5, _check_loaded)

        await _check_loaded(0)

    async def _async_register_modules(self) -> None:
        existing_resources = [
            r for r in self.lovelace.resources.async_items()
            if r["url"].startswith(URL_BASE)
        ]

        for module in JSMODULES:
            url = f"{URL_BASE}/{module['filename']}"
            registered = False

            for resource in existing_resources:
                if self._get_path(resource["url"]) == url:
                    registered = True
                    if self._get_version(resource["url"]) != module["version"]:
                        _LOGGER.info("Mise à jour de %s vers %s", module["name"], module["version"])
                        await self.lovelace.resources.async_update_item(
                            resource["id"],
                            {"res_type": "module", "url": f"{url}?v={module['version']}"},
                        )
                    break

            if not registered:
                _LOGGER.info("Enregistrement de %s version %s", module["name"], module["version"])
                await self.lovelace.resources.async_create_item(
                    {"res_type": "module", "url": f"{url}?v={module['version']}"}
                )

    def _get_path(self, url: str) -> str:
        return url.split("?")[0]

    def _get_version(self, url: str) -> str:
        parts = url.split("?")
        if len(parts) > 1 and parts[1].startswith("v="):
            return parts[1].replace("v=", "")
        return "0"

    async def async_unregister(self) -> None:
        resource_mode = getattr(self.lovelace, "resource_mode", None) or getattr(self.lovelace, "mode", None)
        if self.lovelace is not None and resource_mode == "storage":
            for module in JSMODULES:
                url = f"{URL_BASE}/{module['filename']}"
                resources = [
                    r for r in self.lovelace.resources.async_items()
                    if r["url"].startswith(url)
                ]
                for resource in resources:
                    await self.lovelace.resources.async_delete_item(resource["id"])
