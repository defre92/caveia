// Carte Lovelace CaveIA — aucune configuration requise : elle détecte
// automatiquement les entités caveia_* présentes (caves, humidors, stats).

const GLOBAL_IDS = {
  bottles: "sensor.caveia_bouteilles_totales",
  aBoire: "sensor.caveia_a_boire",
  apogee: "sensor.caveia_apogee",
  cigars: "sensor.caveia_cigares_disponibles",
};

function fillColor(pct) {
  if (pct >= 90) return "#D4543A"; // rouge
  if (pct >= 60) return "#E8912A"; // amber
  return "#4CAF72"; // vert
}

function donutSvg(pct, size = 64) {
  const r = size / 2 - 6;
  const c = 2 * Math.PI * r;
  const offset = c - (Math.min(pct, 100) / 100) * c;
  const color = fillColor(pct);
  return `
    <svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">
      <circle cx="${size / 2}" cy="${size / 2}" r="${r}" fill="none"
        stroke="#3d1f27" stroke-width="6" />
      <circle cx="${size / 2}" cy="${size / 2}" r="${r}" fill="none"
        stroke="${color}" stroke-width="6" stroke-linecap="round"
        stroke-dasharray="${c}" stroke-dashoffset="${offset}"
        transform="rotate(-90 ${size / 2} ${size / 2})"
        style="transition: stroke-dashoffset .6s ease" />
      <text x="50%" y="52%" text-anchor="middle" dominant-baseline="middle"
        fill="#f5e8eb" font-size="15" font-weight="700">${Math.round(pct)}%</text>
    </svg>`;
}

class CaveiaCard extends HTMLElement {
  setConfig(config) {
    this._config = config || {};
    if (!this._listenerAttached) {
      this.addEventListener("click", (ev) => this._onClick(ev));
      this._listenerAttached = true;
    }
  }

  static getStubConfig() {
    return {};
  }

  getCardSize() {
    return 6;
  }

  _onClick(ev) {
    const tile = ev.target.closest(".tile");
    if (tile && this._hass) {
      const entityId = tile.dataset.entity;
      const kind = tile.dataset.kind;
      const st = this._hass.states[entityId];
      if (!st) return;

      if (kind === "cellar") {
        this._openCellarModal(st);
      } else if (kind === "humidor") {
        this._openHumidorModal(st);
      }
      return;
    }

    const actionBtn = ev.target.closest("[data-action]");
    if (actionBtn) {
      this._onAction(actionBtn);
    }
  }

  async _onAction(btn) {
    const action = btn.dataset.action;
    btn.disabled = true;
    btn.textContent = "…";
    try {
      if (action === "consume-bottle") {
        const data = { bottle_id: btn.dataset.bottleId };
        if (btn.dataset.positionIndex !== undefined) {
          data.position_index = Number(btn.dataset.positionIndex);
        }
        await this._hass.callService("caveia", "consume_bottle", data);
      } else if (action === "consume-cigar") {
        await this._hass.callService("caveia", "consume_cigar", { cigar_id: btn.dataset.cigarId });
      }
      const row = btn.closest(".caveia-modal-row");
      if (row) row.style.opacity = "0.35";
      btn.textContent = "✓";
    } catch (e) {
      btn.disabled = false;
      btn.textContent = "Réessayer";
    }
  }

  _openCellarModal(st) {
    const bottles = st.attributes.bottles || [];
    const rows = [];
    bottles.forEach((b) => {
      const label = b.name + (b.vintage ? ` (${b.vintage})` : "");
      const positions = b.positions || [];
      if (positions.length > 1) {
        positions.forEach((p, i) => {
          const loc = p.row != null ? `Rangée ${p.row}${p.col != null ? ` · Col ${p.col}` : ""}` : `Emplacement ${i + 1}`;
          rows.push({
            label, sub: loc,
            actionHtml: `<button class="caveia-modal-btn" data-action="consume-bottle" data-bottle-id="${b.id}" data-position-index="${p.index}">Retirer</button>`,
          });
        });
      } else {
        const p = positions[0];
        rows.push({
          label, sub: "1 bouteille",
          actionHtml: `<button class="caveia-modal-btn" data-action="consume-bottle" data-bottle-id="${b.id}"${p ? ` data-position-index="${p.index}"` : ""}>Retirer</button>`,
        });
      }
    });
    this._openModal(st.attributes.friendly_name.replace(/^CaveIA\s*/, ""), rows, "Cette cave est vide.");
  }

  _openHumidorModal(st) {
    const humidorId = st.attributes.humidor_id;
    const cigarsSt = this._hass.states["sensor.caveia_cigares_disponibles"];
    const allCigars = cigarsSt ? cigarsSt.attributes.cigars || [] : [];
    const cigars = allCigars.filter((c) => c.humidor_id === humidorId);
    const rows = cigars.map((c) => ({
      label: `${c.brand || ""} ${c.name || ""}`.trim(),
      sub: [c.shelf, c.quantity > 1 ? `${c.quantity} restants` : null].filter(Boolean).join(" · ") || "1 restant",
      actionHtml: `<button class="caveia-modal-btn" data-action="consume-cigar" data-cigar-id="${c.id}">Fumer</button>`,
    }));
    this._openModal(st.attributes.friendly_name.replace(/^CaveIA\s*/, ""), rows, "Aucun cigare dans cet humidor.");
  }

  _openModal(title, rows, emptyText) {
    this._closeModal();

    const overlay = document.createElement("div");
    overlay.className = "caveia-modal-overlay";
    overlay.innerHTML = `
      <style>
        .caveia-modal-overlay { position:fixed; inset:0; background:rgba(0,0,0,.6); z-index:1000;
          display:flex; align-items:center; justify-content:center; padding:20px; }
        .caveia-modal { background:#1a0f11; border:1px solid #3d1f27; border-radius:16px;
          max-width:440px; width:100%; max-height:70vh; display:flex; flex-direction:column;
          font-family: var(--paper-font-body1_-_font-family); color:#f5e8eb; }
        .caveia-modal-header { display:flex; align-items:center; justify-content:space-between;
          padding:16px 18px; border-bottom:1px solid #3d1f27; }
        .caveia-modal-header h3 { margin:0; font-size:16px; font-weight:700; }
        .caveia-modal-close { cursor:pointer; background:transparent; border:none; color:#9a7580;
          font-size:20px; line-height:1; padding:4px; }
        .caveia-modal-body { overflow-y:auto; padding:8px 18px 18px; }
        .caveia-modal-row { display:flex; justify-content:space-between; align-items:center;
          gap:10px; padding:9px 0; border-bottom:1px solid #2a1820; font-size:13px; transition:opacity .3s; }
        .caveia-modal-row:last-child { border-bottom:none; }
        .caveia-modal-row-text { min-width:0; }
        .caveia-modal-sub { color:#9a7580; font-size:11px; margin-top:1px; }
        .caveia-modal-btn { flex-shrink:0; background:transparent; color:#D4543A; border:1px solid #D4543A;
          border-radius:8px; padding:5px 12px; font-size:12px; font-weight:600; cursor:pointer; transition:all .15s; }
        .caveia-modal-btn:hover { background:#D4543A; color:#fff; }
        .caveia-modal-btn:disabled { opacity:.6; cursor:default; }
        .caveia-modal-empty { padding:16px 0; color:#9a7580; font-size:13px; text-align:center; }
      </style>
      <div class="caveia-modal">
        <div class="caveia-modal-header">
          <h3>${title}</h3>
          <button class="caveia-modal-close" aria-label="Fermer">✕</button>
        </div>
        <div class="caveia-modal-body">
          ${
            rows && rows.length
              ? rows.map((r) => `
                  <div class="caveia-modal-row">
                    <div class="caveia-modal-row-text">
                      <div>${r.label}</div>
                      ${r.sub ? `<div class="caveia-modal-sub">${r.sub}</div>` : ""}
                    </div>
                    ${r.actionHtml || ""}
                  </div>`).join("")
              : `<div class="caveia-modal-empty">${emptyText || "Rien à afficher."}</div>`
          }
        </div>
      </div>`;

    overlay.addEventListener("click", (ev) => {
      if (ev.target === overlay || ev.target.closest(".caveia-modal-close")) {
        this._closeModal();
        return;
      }
      const actionBtn = ev.target.closest("[data-action]");
      if (actionBtn) this._onAction(actionBtn);
    });

    document.body.appendChild(overlay);
    this._modalEl = overlay;
  }

  _closeModal() {
    if (this._modalEl) {
      this._modalEl.remove();
      this._modalEl = null;
    }
  }

  set hass(hass) {
    this._hass = hass;
    this._render();
  }

  disconnectedCallback() {
    this._closeModal();
  }

  _findByAttr(hass, attrKey) {
    return Object.keys(hass.states)
      .filter((id) => id.startsWith("sensor.caveia_"))
      .map((id) => hass.states[id])
      .filter((st) => st.attributes && Object.prototype.hasOwnProperty.call(st.attributes, attrKey));
  }

  _render() {
    const hass = this._hass;
    if (!hass) return;

    const bottlesSt = hass.states[GLOBAL_IDS.bottles];
    const aBoireSt = hass.states[GLOBAL_IDS.aBoire];
    const apogeeSt = hass.states[GLOBAL_IDS.apogee];
    const cigarsSt = hass.states[GLOBAL_IDS.cigars];

    if (!bottlesSt) {
      this.innerHTML = `
        <ha-card>
          <div style="padding:16px;color:var(--secondary-text-color);">
            Intégration CaveIA introuvable. Ajoute-la depuis Paramètres → Appareils et services.
          </div>
        </ha-card>`;
      return;
    }

    const cellars = this._findByAttr(hass, "cellar_id").sort((a, b) =>
      a.attributes.friendly_name.localeCompare(b.attributes.friendly_name)
    );
    const humidors = this._findByAttr(hass, "humidor_id").sort((a, b) =>
      a.attributes.friendly_name.localeCompare(b.attributes.friendly_name)
    );

    const aBoireList = (bottlesSt.attributes.a_boire || []);
    const apogeeList = (bottlesSt.attributes.apogee || []);
    const cigarsList = (cigarsSt ? cigarsSt.attributes.cigars || [] : []);

    const statChip = (icon, label, value, color) => `
      <div class="stat-chip">
        <ha-icon icon="${icon}" style="color:${color || "var(--caveia-accent)"}"></ha-icon>
        <div class="stat-chip-value">${value}</div>
        <div class="stat-chip-label">${label}</div>
      </div>`;

    const cellarTile = (st) => {
      const a = st.attributes;
      const pct = Number(st.state) || 0;
      return `
        <div class="tile" data-kind="cellar" data-entity="${st.entity_id}">
          ${donutSvg(pct)}
          <div class="tile-info">
            <div class="tile-name">${a.friendly_name.replace(/^CaveIA\s*/, "")}</div>
            <div class="tile-sub">${a.occupied ?? "?"} / ${a.total ?? "?"} bouteilles</div>
            <div class="tile-meta">
              ${a.temperature != null ? `<span><ha-icon icon="mdi:thermometer"></ha-icon>${a.temperature}°C</span>` : ""}
              ${a.humidity != null ? `<span><ha-icon icon="mdi:water-percent"></ha-icon>${a.humidity}%</span>` : ""}
            </div>
          </div>
        </div>`;
    };

    const humidorTile = (st) => {
      const a = st.attributes;
      const humidity = Number(st.state) || 0;
      return `
        <div class="tile" data-kind="humidor" data-entity="${st.entity_id}">
          ${donutSvg(humidity)}
          <div class="tile-info">
            <div class="tile-name">${a.friendly_name.replace(/^CaveIA\s*/, "")}</div>
            <div class="tile-sub">Humidité</div>
            <div class="tile-meta">
              ${a.temperature != null ? `<span><ha-icon icon="mdi:thermometer"></ha-icon>${a.temperature}°C</span>` : ""}
            </div>
          </div>
        </div>`;
    };

    const listRow = (label, sub) => `
      <div class="list-row">
        <span class="list-dot"></span>
        <div>
          <div class="list-label">${label}</div>
          ${sub ? `<div class="list-sub">${sub}</div>` : ""}
        </div>
      </div>`;

    const bottleRows = [
      ...apogeeList.map((b) => listRow(
        b.name + (b.vintage ? ` (${b.vintage})` : ""),
        `Apogée${b.quantity > 1 ? ` · ${b.quantity} restantes` : ""}`
      )),
      ...aBoireList.map((b) => listRow(
        b.name + (b.vintage ? ` (${b.vintage})` : ""),
        b.quantity > 1 ? `${b.quantity} restantes` : ""
      )),
    ].join("") || `<div class="empty">Rien à boire pour l'instant 🍷</div>`;

    const cigarRows = cigarsList.map((c) => listRow(
      `${c.brand || ""} ${c.name || ""}`.trim(),
      c.quantity > 1 ? `${c.quantity} restants` : ""
    )).join("") || `<div class="empty">Aucun cigare disponible</div>`;

    this.innerHTML = `
      <ha-card>
        <style>
          :host, ha-card { --caveia-accent: #D4543A; --caveia-bordeaux: #6B2D3E; }
          .caveia-wrap { padding: 16px; font-family: var(--paper-font-body1_-_font-family); }
          .caveia-header { display:flex; align-items:center; gap:10px; margin-bottom:16px; }
          .caveia-header ha-icon { color: var(--caveia-accent); }
          .caveia-header span { font-size:18px; font-weight:700; }

          .stats-row { display:grid; grid-template-columns:repeat(auto-fit,minmax(80px,1fr)); gap:10px; margin-bottom:20px; }
          .stat-chip { background:var(--card-background-color, #1a0f11); border:1px solid var(--divider-color,#3d1f27);
            border-radius:12px; padding:10px 8px; text-align:center; }
          .stat-chip-value { font-size:20px; font-weight:800; margin-top:4px; }
          .stat-chip-label { font-size:10px; color:var(--secondary-text-color); text-transform:uppercase; letter-spacing:.4px; }

          .section-title { font-size:12px; font-weight:700; text-transform:uppercase; letter-spacing:.5px;
            color:var(--secondary-text-color); margin: 18px 0 10px; }

          .tiles { display:grid; grid-template-columns:repeat(auto-fill,minmax(210px,1fr)); gap:10px; }
          .tile { display:flex; align-items:center; gap:10px; background:var(--card-background-color,#1a0f11);
            border:1px solid var(--divider-color,#3d1f27); border-radius:14px; padding:10px; transition:transform .15s; cursor:pointer; }
          .tile:hover { transform: translateY(-2px); border-color: var(--caveia-accent); }
          .tile-name { font-weight:600; font-size:13px; }
          .tile-sub { font-size:11px; color:var(--secondary-text-color); margin-top:1px; }
          .tile-meta { display:flex; gap:10px; font-size:11px; color:var(--secondary-text-color); margin-top:4px; }
          .tile-meta ha-icon { --mdc-icon-size:13px; margin-right:2px; vertical-align:middle; }

          .list-row { display:flex; align-items:center; gap:10px; padding:7px 4px; border-bottom:1px solid var(--divider-color,#2a1820); }
          .list-row:last-child { border-bottom:none; }
          .list-dot { width:6px; height:6px; border-radius:50%; background:var(--caveia-accent); flex-shrink:0; }
          .list-label { font-size:13px; font-weight:500; }
          .list-sub { font-size:11px; color:var(--secondary-text-color); }
          .empty { font-size:12px; color:var(--secondary-text-color); padding:8px 4px; }
        </style>
        <div class="caveia-wrap">
          <div class="caveia-header">
            <ha-icon icon="mdi:bottle-wine"></ha-icon>
            <span>CaveIA</span>
          </div>

          <div class="stats-row">
            ${statChip("mdi:bottle-wine", "Bouteilles", bottlesSt.state)}
            ${statChip("mdi:glass-wine", "À boire", aBoireSt ? aBoireSt.state : "—", "#D4A843")}
            ${statChip("mdi:alert", "Apogée", apogeeSt ? apogeeSt.state : "—", "#D4543A")}
            ${statChip("mdi:cigar", "Cigares", cigarsSt ? cigarsSt.state : "—")}
          </div>

          ${cellars.length ? `<div class="section-title">Caves</div><div class="tiles">${cellars.map(cellarTile).join("")}</div>` : ""}
          ${humidors.length ? `<div class="section-title">Humidors</div><div class="tiles">${humidors.map(humidorTile).join("")}</div>` : ""}

          <div class="section-title">🍷 À consommer</div>
          <div>${bottleRows}</div>

          <div class="section-title">🚬 Cigares disponibles</div>
          <div>${cigarRows}</div>
        </div>
      </ha-card>`;
  }
}

customElements.define("caveia-card", CaveiaCard);

window.customCards = window.customCards || [];
window.customCards.push({
  type: "caveia-card",
  name: "CaveIA",
  preview: true,
  description: "Vue d'ensemble de ta cave à vins et cigares — zéro configuration.",
});
