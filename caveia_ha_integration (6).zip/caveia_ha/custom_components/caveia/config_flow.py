"""Config Flow CaveIA — l'utilisateur colle son token, on valide en appelant
l'export une fois avant de créer l'entrée."""
from __future__ import annotations

import logging
from typing import Any

import async_timeout
import voluptuous as vol
from aiohttp import ClientError

from homeassistant import config_entries
from homeassistant.data_entry_flow import FlowResult
from homeassistant.helpers.aiohttp_client import async_get_clientsession

from .const import CONF_API_TOKEN, CONF_SCAN_INTERVAL, DEFAULT_SCAN_INTERVAL, DOMAIN, EXPORT_ENDPOINT, MIN_SCAN_INTERVAL

_LOGGER = logging.getLogger(__name__)

STEP_USER_DATA_SCHEMA = vol.Schema({vol.Required(CONF_API_TOKEN): str})


async def _validate_token(hass, token: str) -> None:
    """Lève une exception si le token est invalide ou l'API injoignable."""
    session = async_get_clientsession(hass)
    headers = {"Authorization": f"Bearer {token}"}
    async with async_timeout.timeout(15):
        async with session.get(EXPORT_ENDPOINT, headers=headers) as resp:
            if resp.status == 401:
                raise InvalidAuth
            resp.raise_for_status()


class CaveiaConfigFlow(config_entries.ConfigFlow, domain=DOMAIN):
    """Gère le flux de configuration de l'intégration CaveIA."""

    VERSION = 1

    async def async_step_user(
        self, user_input: dict[str, Any] | None = None
    ) -> FlowResult:
        errors: dict[str, str] = {}

        if user_input is not None:
            token = user_input[CONF_API_TOKEN].strip()

            try:
                await _validate_token(self.hass, token)
            except InvalidAuth:
                errors["base"] = "invalid_auth"
            except (ClientError, TimeoutError):
                errors["base"] = "cannot_connect"
            except Exception:  # noqa: BLE001
                _LOGGER.exception("Erreur inattendue lors de la validation du token CaveIA")
                errors["base"] = "unknown"
            else:
                await self.async_set_unique_id(f"caveia_{token[-8:]}")
                self._abort_if_unique_id_configured()
                return self.async_create_entry(
                    title="CaveIA",
                    data={CONF_API_TOKEN: token},
                )

        return self.async_show_form(
            step_id="user",
            data_schema=STEP_USER_DATA_SCHEMA,
            errors=errors,
            description_placeholders={"help_url": "https://caveia.fr/aide"},
        )

    @staticmethod
    def async_get_options_flow(config_entry: config_entries.ConfigEntry) -> CaveiaOptionsFlow:
        return CaveiaOptionsFlow(config_entry)


class CaveiaOptionsFlow(config_entries.OptionsFlow):
    """Permet de régler la fréquence de rafraîchissement après coup."""

    def __init__(self, config_entry: config_entries.ConfigEntry) -> None:
        self.config_entry = config_entry

    async def async_step_init(self, user_input: dict[str, Any] | None = None) -> FlowResult:
        if user_input is not None:
            return self.async_create_entry(title="", data=user_input)

        current = self.config_entry.options.get(CONF_SCAN_INTERVAL, DEFAULT_SCAN_INTERVAL)
        schema = vol.Schema({
            vol.Optional(CONF_SCAN_INTERVAL, default=current): vol.All(
                vol.Coerce(int), vol.Range(min=MIN_SCAN_INTERVAL)
            )
        })
        return self.async_show_form(step_id="init", data_schema=schema)


class InvalidAuth(Exception):
    """Token invalide ou révoqué."""
