"""Listes de tâches CaveIA : bouteilles à boire, cigares disponibles.

Cocher un élément (ou le supprimer d'un swipe) déclenche automatiquement la
sortie de la bouteille / la consommation du cigare correspondant dans
CaveIA — aucune automatisation à configurer.
"""
from __future__ import annotations

import logging

from homeassistant.components.todo import (
    TodoItem,
    TodoItemStatus,
    TodoListEntity,
    TodoListEntityFeature,
)
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity import DeviceInfo
from homeassistant.helpers.entity_platform import AddEntitiesCallback
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from .const import DOMAIN, MANUFACTURER, UID_SEP
from .coordinator import CaveiaCoordinator

_LOGGER = logging.getLogger(__name__)


def _device_info(entry: ConfigEntry) -> DeviceInfo:
    return DeviceInfo(
        identifiers={(DOMAIN, entry.entry_id)},
        name="CaveIA",
        manufacturer=MANUFACTURER,
        entry_type="service",
    )


async def async_setup_entry(
    hass: HomeAssistant, entry: ConfigEntry, async_add_entities: AddEntitiesCallback
) -> None:
    coordinator: CaveiaCoordinator = hass.data[DOMAIN][entry.entry_id]["coordinator"]
    async_add_entities([
        CaveiaBottlesTodoList(coordinator, entry),
        CaveiaCigarsTodoList(coordinator, entry),
    ])


class CaveiaBottlesTodoList(CoordinatorEntity[CaveiaCoordinator], TodoListEntity):
    """Bouteilles prêtes à boire / à l'apogée. Glisser pour supprimer = marquer sortie.
    (Pas de case à cocher : trop facile à déclencher par accident, surtout
    sur des bouteilles en plusieurs exemplaires.)"""

    _attr_has_entity_name = True
    _attr_name = "Bouteilles à boire"
    _attr_icon = "mdi:glass-wine"
    _attr_supported_features = TodoListEntityFeature.DELETE_TODO_ITEM

    def __init__(self, coordinator: CaveiaCoordinator, entry: ConfigEntry) -> None:
        super().__init__(coordinator)
        self._attr_unique_id = f"{entry.entry_id}{UID_SEP}todo_bottles"
        self._attr_device_info = _device_info(entry)
        self._refresh_items()

    def _refresh_items(self) -> None:
        bottles = (self.coordinator.data or {}).get("bottles", {})
        items = []
        for b in bottles.get("apogee", []):
            label = b["name"] + (f" ({b['vintage']})" if b.get("vintage") else "")
            if b.get("quantity", 1) > 1:
                label += f" · {b['quantity']} restantes"
            label += " — apogée"
            items.append(TodoItem(summary=label, uid=b["id"], status=TodoItemStatus.NEEDS_ACTION))
        for b in bottles.get("a_boire", []):
            label = b["name"] + (f" ({b['vintage']})" if b.get("vintage") else "")
            if b.get("quantity", 1) > 1:
                label += f" · {b['quantity']} restantes"
            items.append(TodoItem(summary=label, uid=b["id"], status=TodoItemStatus.NEEDS_ACTION))
        self._attr_todo_items = items

    def _handle_coordinator_update(self) -> None:
        self._refresh_items()
        super()._handle_coordinator_update()

    async def async_delete_todo_items(self, uids: list[str]) -> None:
        for uid in uids:
            await self.coordinator.async_sortie_bottle(uid)


class CaveiaCigarsTodoList(CoordinatorEntity[CaveiaCoordinator], TodoListEntity):
    """Cigares disponibles. Glisser pour supprimer = marquer fumé."""

    _attr_has_entity_name = True
    _attr_name = "Cigares disponibles"
    _attr_icon = "mdi:cigar"
    _attr_supported_features = TodoListEntityFeature.DELETE_TODO_ITEM

    def __init__(self, coordinator: CaveiaCoordinator, entry: ConfigEntry) -> None:
        super().__init__(coordinator)
        self._attr_unique_id = f"{entry.entry_id}{UID_SEP}todo_cigars"
        self._attr_device_info = _device_info(entry)
        self._refresh_items()

    def _refresh_items(self) -> None:
        cigars = (self.coordinator.data or {}).get("cigars_available", [])
        items = []
        for c in cigars:
            label = f"{c.get('brand', '')} {c.get('name', '')}".strip()
            if c.get("quantity", 1) > 1:
                label += f" · {c['quantity']} restants"
            items.append(TodoItem(summary=label, uid=c["id"], status=TodoItemStatus.NEEDS_ACTION))
        self._attr_todo_items = items

    def _handle_coordinator_update(self) -> None:
        self._refresh_items()
        super()._handle_coordinator_update()

    async def async_delete_todo_items(self, uids: list[str]) -> None:
        for uid in uids:
            await self.coordinator.async_fumer_cigar(uid)
