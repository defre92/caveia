"""Constantes pour l'intégration CaveIA."""

from pathlib import Path
import json
from typing import Final

MANIFEST_PATH = Path(__file__).parent / "manifest.json"
with open(MANIFEST_PATH, encoding="utf-8") as f:
    INTEGRATION_VERSION: Final[str] = json.load(f).get("version", "0.0.0")

DOMAIN = "caveia"

CONF_API_TOKEN = "api_token"

API_BASE_URL = "https://caveia.fr/api/ha"
EXPORT_ENDPOINT = f"{API_BASE_URL}/export"

DEFAULT_SCAN_INTERVAL = 300  # secondes (5 min)
CONF_SCAN_INTERVAL = "scan_interval"
MIN_SCAN_INTERVAL = 30  # secondes — en dessous, trop agressif pour l'API

MANUFACTURER = "CaveIA"

SERVICE_SET_CONDITIONS = "set_conditions"
SERVICE_CONSUME_BOTTLE = "consume_bottle"
SERVICE_CONSUME_CIGAR = "consume_cigar"
ATTR_TEMPERATURE = "temperature"
ATTR_HUMIDITY = "humidity"
ATTR_BOTTLE_ID = "bottle_id"
ATTR_CIGAR_ID = "cigar_id"
ATTR_POSITION_INDEX = "position_index"

# Séparateur utilisé dans les unique_id pour distinguer "quelle entrée / quel
# type / quel id CaveIA" sans risque de collision avec un UUID.
UID_SEP = "::"

# Carte Lovelace embarquée
URL_BASE: Final[str] = "/caveia_frontend"
JSMODULES: Final[list[dict[str, str]]] = [
    {
        "name": "CaveIA Card",
        "filename": "caveia-card.js",
        "version": INTEGRATION_VERSION,
    },
]
