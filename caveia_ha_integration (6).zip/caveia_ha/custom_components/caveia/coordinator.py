"""Coordinator : interroge /api/ha/export périodiquement et partage le résultat
entre toutes les entités de l'intégration."""
from __future__ import annotations

import logging
from datetime import timedelta

import async_timeout
from aiohttp import ClientError

from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.exceptions import ConfigEntryAuthFailed
from homeassistant.helpers.aiohttp_client import async_get_clientsession
from homeassistant.helpers.update_coordinator import DataUpdateCoordinator, UpdateFailed

from .const import CONF_API_TOKEN, CONF_SCAN_INTERVAL, DEFAULT_SCAN_INTERVAL, API_BASE_URL, EXPORT_ENDPOINT

_LOGGER = logging.getLogger(__name__)


class CaveiaCoordinator(DataUpdateCoordinator[dict]):
    """Récupère et met en cache les données CaveIA (bouteilles, caves, humidors)."""

    def __init__(self, hass: HomeAssistant, entry: ConfigEntry) -> None:
        interval = entry.options.get(CONF_SCAN_INTERVAL, DEFAULT_SCAN_INTERVAL)
        super().__init__(
            hass,
            _LOGGER,
            name="CaveIA",
            update_interval=timedelta(seconds=interval),
        )
        self.entry = entry
        self._token = entry.data[CONF_API_TOKEN]

    async def _async_update_data(self) -> dict:
        session = async_get_clientsession(self.hass)
        headers = {"Authorization": f"Bearer {self._token}"}

        try:
            async with async_timeout.timeout(15):
                async with session.get(EXPORT_ENDPOINT, headers=headers) as resp:
                    if resp.status == 401:
                        raise ConfigEntryAuthFailed("Token CaveIA invalide ou révoqué")
                    resp.raise_for_status()
                    return await resp.json()
        except ConfigEntryAuthFailed:
            raise
        except (ClientError, TimeoutError) as err:
            raise UpdateFailed(f"Erreur de connexion à CaveIA : {err}") from err

    async def async_push_conditions(
        self, kind: str, item_id: str, temperature: float | None, humidity: float | None
    ) -> None:
        """Pousse température/humidité vers CaveIA (cave ou humidor), puis
        rafraîchit immédiatement les données locales (pas d'attente 5 min)."""
        session = async_get_clientsession(self.hass)
        headers = {"Authorization": f"Bearer {self._token}"}
        path = "cellars" if kind == "cellar" else "humidors"
        url = f"{API_BASE_URL}/{path}/{item_id}/conditions"

        params = {}
        if temperature is not None:
            params["temperature"] = temperature
        if humidity is not None:
            params["humidity"] = humidity

        try:
            async with async_timeout.timeout(15):
                async with session.post(url, headers=headers, params=params) as resp:
                    if resp.status == 401:
                        raise ConfigEntryAuthFailed("Token CaveIA invalide ou révoqué")
                    resp.raise_for_status()
        except ConfigEntryAuthFailed:
            raise
        except (ClientError, TimeoutError) as err:
            raise UpdateFailed(f"Erreur en poussant les conditions vers CaveIA : {err}") from err

        await self.async_request_refresh()

    async def async_sortie_bottle(self, bottle_id: str, quantity: int = 1, position_index: int | None = None) -> None:
        """Marque une bouteille sortie dans CaveIA (avec choix optionnel de l'emplacement)."""
        params = {"quantity": quantity}
        if position_index is not None:
            params["position_index"] = position_index
        await self._post_action(f"{API_BASE_URL}/bottles/{bottle_id}/sortie", params)

    async def async_fumer_cigar(self, cigar_id: str, quantity: int = 1) -> None:
        """Marque un cigare fumé dans CaveIA."""
        await self._post_action(f"{API_BASE_URL}/cigars/{cigar_id}/fumer", {"quantity": quantity})

    async def _post_action(self, url: str, params: dict) -> None:
        session = async_get_clientsession(self.hass)
        headers = {"Authorization": f"Bearer {self._token}"}
        try:
            async with async_timeout.timeout(15):
                async with session.post(url, headers=headers, params=params) as resp:
                    if resp.status == 401:
                        raise ConfigEntryAuthFailed("Token CaveIA invalide ou révoqué")
                    resp.raise_for_status()
        except ConfigEntryAuthFailed:
            raise
        except (ClientError, TimeoutError) as err:
            raise UpdateFailed(f"Erreur en appelant CaveIA : {err}") from err

        await self.async_request_refresh()
